package com.project.backendapi.tenant;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.UUID;

@Service
public class TenantMembershipService {
    private final JdbcTemplate jdbc;
    public TenantMembershipService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Transactional(readOnly = true)
    public String requireRole(UUID tenantId, String userKey, String... allowedRoles) {
        // Set tenant scope transaction-locally before querying RLS-protected membership rows.
        jdbc.queryForObject("select set_config('app.tenant_id', ?, true)", String.class, tenantId.toString());
        var roles = jdbc.query(
            "select tm.role from tenant_memberships tm join users u on u.id=tm.user_id " +
            "where tm.tenant_id=? and u.entra_object_id=? and tm.status='ACTIVE'",
            (rs, row) -> rs.getString(1), tenantId, userKey);
        if (roles.isEmpty()) throw new org.springframework.security.access.AccessDeniedException("No active tenant membership");
        String role = roles.get(0);
        for (String allowed : allowedRoles) if (allowed.equals(role)) return role;
        throw new org.springframework.security.access.AccessDeniedException("Insufficient tenant role");
    }
}
