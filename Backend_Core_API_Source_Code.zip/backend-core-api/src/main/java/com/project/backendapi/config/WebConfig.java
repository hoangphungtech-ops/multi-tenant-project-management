package com.project.backendapi.config;

import com.project.backendapi.tenant.TenantContextFilter;
import com.project.backendapi.tenant.TenantMembershipInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    private final TenantMembershipInterceptor membershipInterceptor;
    public WebConfig(TenantMembershipInterceptor membershipInterceptor) { this.membershipInterceptor = membershipInterceptor; }
    @Override public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(membershipInterceptor).addPathPatterns("/api/v1/tenants/**");
    }
}
