package com.project.backendapi.export;

import com.project.backendapi.security.CurrentUser;
import com.project.backendapi.tenant.TenantMembershipService;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.time.OffsetDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/v1/tenants/{tenantId}/exports")
public class ExportController {
    private final ExportJobRepository jobs;
    private final TenantMembershipService memberships;
    private final CurrentUser currentUser;
    private final ExportQueueService queue;
    private final JdbcTemplate jdbc;

    public ExportController(ExportJobRepository jobs, TenantMembershipService memberships, CurrentUser currentUser,
                            ExportQueueService queue, JdbcTemplate jdbc) {
        this.jobs=jobs; this.memberships=memberships; this.currentUser=currentUser; this.queue=queue; this.jdbc=jdbc;
    }
    private String user() { return currentUser.userKey(SecurityContextHolder.getContext().getAuthentication()); }

    @PostMapping
    public ResponseEntity<Map<String,Object>> create(@PathVariable UUID tenantId) {
        memberships.requireRole(tenantId,user(),"OWNER","MEMBER");
        jdbc.queryForObject("select set_config('app.tenant_id', ?, true)", String.class, tenantId.toString());
        ExportJob job = jobs.save(new ExportJob(tenantId));
        String messageId = queue.enqueue(job.getId(), tenantId);
        job.setQueueMessageId(messageId);
        jobs.save(job);
        return ResponseEntity.accepted().body(Map.of("id",job.getId(),"status",job.getStatus(),"queueMessageId",messageId));
    }

    @GetMapping("/{jobId}")
    public Map<String,Object> get(@PathVariable UUID tenantId,@PathVariable UUID jobId) {
        memberships.requireRole(tenantId,user(),"OWNER","MEMBER","GUEST");
        jdbc.queryForObject("select set_config('app.tenant_id', ?, true)", String.class, tenantId.toString());
        ExportJob job=jobs.findByIdAndTenantId(jobId,tenantId).orElseThrow();
        return Map.of("id",job.getId(),"status",job.getStatus());
    }
}
