-- Repeatable, idempotent development seed. Fixed IDs make local API examples predictable.
INSERT INTO tenants (id, name)
VALUES ('11111111-1111-1111-1111-111111111111', 'Demo Tenant')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO users (id, entra_object_id, email, display_name)
VALUES ('22222222-2222-2222-2222-222222222222', 'demo-owner', 'owner@example.local', 'Demo Owner')
ON CONFLICT (entra_object_id) DO UPDATE
SET email = EXCLUDED.email, display_name = EXCLUDED.display_name;

INSERT INTO tenant_memberships (tenant_id, user_id, role, status)
VALUES ('11111111-1111-1111-1111-111111111111',
        '22222222-2222-2222-2222-222222222222', 'OWNER', 'ACTIVE')
ON CONFLICT (tenant_id, user_id) DO UPDATE
SET role = EXCLUDED.role, status = EXCLUDED.status;
